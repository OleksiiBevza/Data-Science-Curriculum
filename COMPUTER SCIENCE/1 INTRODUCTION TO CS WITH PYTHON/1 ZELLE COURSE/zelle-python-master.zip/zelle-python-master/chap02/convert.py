def main():
    celsius = eval(input("What is the Celsius temperature? "))
    fahrenheit = 9/5 * celius + 32
    print("The temperature is ", fahrenheit, "degrees Fahrenheit.")

main()
