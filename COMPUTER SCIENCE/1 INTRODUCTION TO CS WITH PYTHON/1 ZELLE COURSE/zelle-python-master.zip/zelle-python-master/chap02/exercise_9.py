def main():
    print("Welcome! This program will kindly convert", "\n", "your distance in kilometers to miles.")
    km = eval(input("What is the distance in km? "))
    miles = km * .62
    print("The distance is ", miles, "miles.")

main()
