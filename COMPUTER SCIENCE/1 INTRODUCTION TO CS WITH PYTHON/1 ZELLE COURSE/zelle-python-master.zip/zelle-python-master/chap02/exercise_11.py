def main():
    print("Calculator")
    for i in range(100):
        x = eval(input())
        print(x)

main()
