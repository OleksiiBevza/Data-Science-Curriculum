print("Rectangle!", "America!", "Monday", "Butthole!", sep="\n")
