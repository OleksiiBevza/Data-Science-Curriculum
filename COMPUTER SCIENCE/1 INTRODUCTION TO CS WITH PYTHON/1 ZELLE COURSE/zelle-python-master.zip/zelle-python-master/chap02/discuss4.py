for i in range(5):
    print(i * i)

for d in [3,1,4,1,5]:
    print(d, end=" ")

for i in range(4):
    print("hello")

for i in range(5):
    print(i, 2**i)
