def oldMac():
    print("Old MacDonald had a farm, Ee-igh, Ei-igh, Oh!")

def animal(animal, sound):
    print("And on this farm he had a(n)", animal +", Ee-igh, Ee-igh, Oh!")
    print("With a(n)", sound + ",", sound, "here, and a(n)", sound+",", sound, "there.")
    print("Here a(n)", sound+",","there a(n)", sound + ",", "everywhere a(n)", sound+",", sound+".")

def main():
    oldMac()
    animal('pig', 'oink')
    oldMac()
    print()
    oldMac()
    animal('cow', 'moo')
    oldMac()
    print()
    oldMac()
    animal('chicken', 'cheep')
    oldMac()
    print()
    oldMac()
    animal('frog', 'ribbit')
    oldMac()
    print()
    oldMac()
    animal('goat', 'bah')
    oldMac()
main()
