#Post-test loop
while True:
    number = eval(input("Enter a positive number: "))
    if number >=0:
        break #Exit loop if number is valid
    else:
            print("The number you entered is not valid. ")

#Loop and a Half
while True:
    number = eval(input("enter a positive number: "))
    if number >= 0: break #Loop Exit
    print("The number you entered was not positive")
    
