#Write an interactive program to play Connect Four or Battleship
